"""Value connector planning capability."""
