# Incidents

Incident records explain historical failure modes and the fixes or follow-up
contracts they motivated. They are evidence, not current operating manuals.

Current records:

- [Outcome floor safe-bypass incident, 2026-06-06](outcome-floor-safe-bypass-incident-20260606.md)
- [Monitor-only replan stall incident, 2026-06-21](monitor-only-replan-stall-incident-20260621.md)
- [Agent-scoped user gate overreach incident, 2026-06-24](agent-scoped-user-gate-overreach-incident-20260624.md)
- [Default workflow planner gap incident, 2026-06-25](default-workflow-planner-gap-incident-20260625.md)
- [Standing authorization reprompt incident, 2026-06-28](standing-authorization-reprompt-incident-20260628.md)
- [Agent-scoped replan precedence incident, 2026-07-03](agent-scoped-replan-precedence-incident-20260703.md)
- [Auto-research replan and multi-round demo bad case, 2026-07-05](auto-research-replan-multiround-badcase-20260705.md)
- [SkillsBench PR #1680 replan bad case, 2026-07-09](skillsbench-pr1680-replan-badcase-20260709.md)
- [SkillsBench Goal baseline comparison incident, 2026-07-11](skillsbench-goal-baseline-comparison-incident-20260711.md)
