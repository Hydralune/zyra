#!/usr/bin/env python3
"""Smoke-test the AgentIssue-Bench Codex CLI runner dry-run wrapper."""

from __future__ import annotations

import json
import subprocess
import sys
import tempfile
from pathlib import Path
from typing import Any


REPO_ROOT = Path(__file__).resolve().parents[1]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from loopx.status import collect_status  # noqa: E402


TOPIC_DIR = REPO_ROOT / "docs" / "research" / "long-horizon-agent-benchmarks"
DOC = TOPIC_DIR / "agentissue-bench-codex-cli-runner-dry-run-wrapper-v0.md"
README = TOPIC_DIR / "README.md"

GOAL_ID = "agentissue-runner-wrapper-fixture"
BENCHMARK_ID = "agentissue-bench"
SELECTED_TAG = "lagent_239"
RUN_MODE = "agentissue_codex_cli_runner_dry_run_wrapper"
CLASSIFICATION = "agentissue_bench_codex_cli_runner_dry_run_wrapper_v0"

REQUIRED_DOC_SNIPPETS = [
    "AgentIssue-Bench Codex CLI Runner Dry-Run Wrapper V0",
    "loopx benchmark agentissue-codex-runner-flow",
    "--tag lagent_239",
    "benchmark_run_v0",
    "codex_cli_invoked",
    "docker_container_started",
    "agentissue_bench_single_tag_container_eval_not_run",
    "python3 examples/agentissue-bench-codex-cli-runner-dry-run-wrapper-smoke.py",
]

FORBIDDEN_TEXT = [
    "/" + "Users/",
    "~/.codex",
    ".codex/auth.json",
    "OPENAI" + "_API_KEY",
    "ANTHROPIC" + "_API_KEY",
    "GOOGLE" + "_API_KEY",
    "CODEX" + "_ACCESS_TOKEN",
    "raw" + "_issue_body:",
    "raw" + "_patch:",
    "raw" + "_log:",
    "trajectory.json",
    "screenshot",
    "show_diff",
]


def write_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def write_fixture(root: Path) -> tuple[Path, Path]:
    project = root / "project"
    runtime = root / "runtime"
    state_file = f".codex/goals/{GOAL_ID}/ACTIVE_GOAL_STATE.md"
    registry_path = project / ".loopx" / "registry.json"

    (project / Path(state_file).parent).mkdir(parents=True, exist_ok=True)
    (project / state_file).write_text(
        "---\n"
        "status: active-read-only\n"
        "updated_at: 2026-06-12T00:00:00+00:00\n"
        "---\n\n"
        "# AgentIssue Runner Wrapper Fixture\n\n"
        "## Agent Todo\n\n"
        "- [ ] Render the AgentIssue-Bench Codex CLI runner wrapper.\n",
        encoding="utf-8",
    )
    write_json(
        registry_path,
        {
            "schema_version": 1,
            "updated_at": "2026-06-12T00:00:00+00:00",
            "common_runtime_root": str(runtime),
            "goals": [
                {
                    "id": GOAL_ID,
                    "domain": "loopx-platform",
                    "status": "active-read-only",
                    "state_file": state_file,
                    "repo": str(project),
                    "adapter": {
                        "kind": "harness_self_improvement",
                        "status": "connected-read-only",
                    },
                    "heartbeat": {
                        "enabled": True,
                    },
                }
            ],
        },
    )
    return registry_path, runtime


def run_cli(args: list[str], *, check: bool = True) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        [sys.executable, "-m", "loopx.cli", *args],
        cwd=REPO_ROOT,
        check=check,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )


def run_cli_json(args: list[str]) -> dict[str, Any]:
    result = run_cli(args)
    payload = json.loads(result.stdout)
    assert isinstance(payload, dict), payload
    return payload


def common_args(registry_path: Path, runtime: Path) -> list[str]:
    return [
        "--registry",
        str(registry_path),
        "--runtime-root",
        str(runtime),
        "--format",
        "json",
        "benchmark",
        "agentissue-codex-runner-flow",
        "--goal-id",
        GOAL_ID,
        "--tag",
        SELECTED_TAG,
        "--no-global-sync",
    ]


def assert_no_forbidden_text(payload: dict[str, Any]) -> None:
    text = json.dumps(payload, sort_keys=True)
    leaked = [marker for marker in FORBIDDEN_TEXT if marker in text]
    assert not leaked, leaked
    assert len(text) < 26000, len(text)


def assert_doc_contract() -> None:
    text = DOC.read_text(encoding="utf-8")
    readme = README.read_text(encoding="utf-8")
    missing = [snippet for snippet in REQUIRED_DOC_SNIPPETS if snippet not in text]
    assert not missing, missing
    assert "agentissue-bench-codex-cli-runner-dry-run-wrapper-v0.md" in readme, readme
    leaked = [marker for marker in FORBIDDEN_TEXT if marker in text]
    assert not leaked, leaked


def assert_payload(payload: dict[str, Any], *, appended: bool) -> None:
    assert payload["ok"] is True, payload
    assert payload["appended"] is appended, payload
    assert payload["dry_run"] is (not appended), payload
    assert payload["classification"] == CLASSIFICATION, payload

    cli = payload["benchmark_cli"]
    assert cli["benchmark"] == BENCHMARK_ID, cli
    assert cli["command"] == "agentissue-codex-runner-flow", cli
    assert cli["tag"] == SELECTED_TAG, cli
    assert cli["dry_run_default"] is True, cli
    assert cli["real_runner_invoked"] is False, cli
    assert cli["real_codex_invoked"] is False, cli
    assert cli["real_docker_invoked"] is False, cli
    assert cli["model_api_invoked"] is False, cli
    assert cli["auth_values_read"] is False, cli

    wrapper = payload["agentissue_runner_flow"]
    assert wrapper["schema_version"] == CLASSIFICATION, wrapper
    assert wrapper["selected_tag"] == SELECTED_TAG, wrapper
    assert wrapper["dry_run_default"] is True, wrapper
    assert wrapper["real_execution_done"] is False, wrapper
    assert wrapper["single_tag_only"] is True, wrapper
    phases = wrapper["staging_plan"]["phase_order"]
    assert phases.index("extract_buggy_source_from_selected_container_opt_in") < phases.index(
        "run_host_local_codex_cli_patch_worker_opt_in"
    ), phases
    assert phases.index("run_host_local_codex_cli_patch_worker_opt_in") < phases.index(
        "write_attempt_patch_from_buggy_source_git_diff"
    ), phases
    assert wrapper["commands"]["codex_patch_worker"]["argv"][0] == "codex", wrapper
    assert "--ephemeral" in wrapper["commands"]["codex_patch_worker"]["argv"], wrapper
    assert wrapper["commands"]["codex_patch_worker"]["auth_material_synced"] is False, wrapper
    assert wrapper["commands"]["single_tag_eval"]["argv"][0] == "docker", wrapper
    assert wrapper["commands"]["single_tag_eval"]["official_all_tag_helper_allowed"] is False, wrapper
    assert wrapper["execution_boundary"]["codex_cli_invoked"] is False, wrapper
    assert wrapper["execution_boundary"]["model_api_invoked"] is False, wrapper
    assert wrapper["execution_boundary"]["docker_container_started"] is False, wrapper
    assert wrapper["execution_boundary"]["patch_generated"] is False, wrapper

    event = payload["benchmark_run"]
    assert event["schema_version"] == "benchmark_run_v0", event
    assert event["source_runner"] == "loopx_agentissue_codex_cli_runner", event
    assert event["benchmark_id"] == BENCHMARK_ID, event
    assert event["mode"] == RUN_MODE, event
    assert event["first_blocker"] == "dry_run_wrapper_only_no_real_case", event
    assert event["real_run"] is False, event
    assert event["submit_eligible"] is False, event
    assert event["leaderboard_evidence"] is False, event
    assert event["official_task_score"]["kind"] == (
        "agentissue_bench_single_tag_container_eval_not_run"
    ), event
    assert event["progress"]["n_total_trials"] == 1, event
    assert event["progress"]["n_pending_trials"] == 1, event
    assert event["metrics"]["cost_usd"] == 0, event
    assert event["validation"]["all_passed"] is True, event
    assert event["validation"]["failed_checks"] == [], event
    assert event["read_boundary"]["compact_only"] is True, event
    assert event["read_boundary"]["docker_invoked"] is False, event
    assert event["read_boundary"]["model_api_invoked"] is False, event
    assert_no_forbidden_text(wrapper)
    assert_no_forbidden_text(event)
    assert_no_forbidden_text(cli)


def assert_status_projection(registry_path: Path, runtime: Path) -> None:
    status = collect_status(
        registry_path=registry_path,
        runtime_root_override=str(runtime),
        scan_roots=[],
        limit=5,
    )
    assert status["ok"], status
    latest = status["run_history"]["goals"][0]["latest_runs"][0]
    summary = latest["benchmark_run_summary"]
    assert summary["mode"] == RUN_MODE, summary
    assert summary["benchmark_id"] == BENCHMARK_ID, summary
    assert summary["progress"]["n_total_trials"] == 1, summary
    assert summary["validation"]["all_passed"] is True, summary
    assert status["event_ledger_summary"]["totals"]["benchmark_runs_24h"] == 1, status
    assert_no_forbidden_text(summary)


def assert_other_tags_rejected(registry_path: Path, runtime: Path) -> None:
    args = common_args(registry_path, runtime)
    tag_index = args.index("--tag") + 1
    args[tag_index] = "other_001"
    result = run_cli(args, check=False)
    assert result.returncode == 1, result.stdout
    payload = json.loads(result.stdout)
    assert payload["ok"] is False, payload
    assert "only supports selected tag" in payload["error"], payload


def main() -> None:
    assert_doc_contract()
    with tempfile.TemporaryDirectory(prefix="agentissue-runner-wrapper-") as tmp:
        registry_path, runtime = write_fixture(Path(tmp))
        dry_payload = run_cli_json(common_args(registry_path, runtime))
        assert_payload(dry_payload, appended=False)

        execute_payload = run_cli_json(
            common_args(registry_path, runtime)
            + [
                "--delivery-batch-scale",
                "multi_surface",
                "--delivery-outcome",
                "outcome_progress",
                "--execute",
            ]
        )
        assert_payload(execute_payload, appended=True)
        assert_status_projection(registry_path, runtime)
        assert_other_tags_rejected(registry_path, runtime)

    print(
        "agentissue-bench-codex-cli-runner-dry-run-wrapper-smoke ok "
        f"mode={RUN_MODE} appended=True real_run=False"
    )


if __name__ == "__main__":
    main()
