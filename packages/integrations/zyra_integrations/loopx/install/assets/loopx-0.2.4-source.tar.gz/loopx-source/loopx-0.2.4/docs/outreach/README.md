# Outreach Drafts

This folder keeps public-safe narrative material: launch notes, demo scripts,
PR drafts, and storyboards. These files can be polished into external messaging
without mixing them into stable product contracts.

Current drafts:

- [Frontstage demo script](frontstage-demo-script.md)
- [Marketing copy bank](marketing-copy-bank.md)
- [Public launch narrative draft](public-launch-narrative-draft.md)
- [Showcase animation skill spike](showcase-animation-skill-spike.md)
- [Xiaohongshu launch draft](xiaohongshu-launch-draft.md)

Keep examples synthetic or public-safe. Do not include raw private benchmark
trajectories, internal URLs, credentials, or personal local paths.
